﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="en-ca" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Kitchener Coed Volleyball League</title>
<style type="text/css">
a:link{cursor:pointer}a:link{color:#1a0dab}
.auto-style1 {
	border-width: 0;
}
.auto-style2 {
	text-align: center;
}
.auto-style3 {
	font-family: Impact, Haettenschweiler, "Arial Narrow Bold", sans-serif;
}
.auto-style5 {
	font-family: georgia, "times new roman", times;
	text-decoration: underline;
	text-align: center;
}
.auto-style4 {
	font-family: georgia, "times new roman", times;
}
.auto-style6 {
	text-decoration: underline;
}
.auto-style7 {
	text-decoration: underline;
	text-align: center;
}
.auto-style9 {
	font-family: Georgia, "Times New Roman", Times, serif;
}
.auto-style10 {
	border: 3px solid #999966;
}
.auto-style11 {
	text-align: center;
	background-color: #999966;
}
.auto-style12 {
	text-align: center;
	color: #FFFFFF;
	background-color: #999966;
}
.auto-style13 {
	color: #FFFFFF;
	border-left-color: #A0A0A0;
	border-right-color: #C0C0C0;
	border-top-color: #A0A0A0;
	border-bottom-color: #C0C0C0;
	padding: 1px;
	background-color: #999966;
}
.auto-style14 {
	color: #FFFFFF;
	background-color: #999966;
}
.auto-style15 {
	text-align: center;
	border-left-color: #A0A0A0;
	border-right-color: #C0C0C0;
	border-top-color: #A0A0A0;
	border-bottom-color: #C0C0C0;
	background-color: #999966;
}
</style>
</head>

<body>

<form id="form1" runat="server">
	<p>
	<table align="center" style="width: 100%">
		<tr>
			<td style="width: 185px">
			<img alt="Image result for volleyball" class="rg_ic rg_i" data-sz="f" jsaction="load:str.tbn" name="SLz0CsGHYpcepM:" onload="google.aft&amp;&amp;google.aft(this)" src="images.gif" style="width: 203px; height: 203px; margin-top: 0px; margin-right: -13px; margin-left: -16px; float: left;" /></td>
			<td class="auto-style2" colspan="2" style="width: 670px">
			<span class="auto-style3"><font size="6"><strong><em>Kitchener Coed 
			Volleyball League</em></strong></font></span><br />
			</td>
			<td valign="bottom">
			<a href="https://www.google.ca/imgres?imgurl=http%3A%2F%2Fwww.witty.ca%2Fuploads%2F4%2F7%2F6%2F4%2F4764474%2F3466918_orig.png%3F144&amp;imgrefurl=http%3A%2F%2Fwww.witty.ca%2Fold-2015-tournament---ms-boys-volleyball.html&amp;docid=cJcFrMD3b-TbKM&amp;tbnid=GCupcdWD7bCIaM%3A&amp;w=425&amp;h=358&amp;bih=874&amp;biw=1280&amp;ved=0ahUKEwily8eHwMHPAhUk1oMKHSNFD8oQxiAIBCgC&amp;iact=c&amp;ictx=1">
			<img alt="Related image" class="auto-style1" src="images.gif" style="width: 203px; height: 170px; margin-left: -7px; float: right;" /></a></td>
		</tr>
		<tr>
			<td class="auto-style2" style="width: 185px">&nbsp;</td>
			<td class="auto-style2" style="width: 670px">&nbsp;</td>
			<td class="auto-style2" style="width: 670px">&nbsp;</td>
			<td class="auto-style2">&nbsp;</td>
		</tr>
		<tr>
			<td class="auto-style11" style="width: 185px">
			<asp:Button id="Button1" runat="server" BackColor="#1A0DAB" Font-Bold="True" ForeColor="White" Height="25px" Text="C Division" Width="100px" />
			&nbsp;</td>
			<td class="auto-style11" style="width: 670px">
			<asp:Button id="Button2" runat="server" BackColor="#1A0DAB" Font-Bold="True" ForeColor="White" Height="25px" Text="D1 Division" Width="100px" />
			</td>
			<td class="auto-style11" style="width: 670px">
			<asp:Button id="Button3" runat="server" BackColor="#1A0DAB" Font-Bold="True" ForeColor="White" Height="25px" Text="D2 Division" Width="100px" />
			</td>
			<td class="auto-style11">
			<asp:Button id="Button4" runat="server" BackColor="#1A0DAB" Font-Bold="True" ForeColor="White" Height="25px" Text="E Division" Width="100px" />
			</td>
		</tr>
		<tr>
			<td class="auto-style12" style="width: 185px">Last Updated: Oct 4, 
			2016</td>
			<td class="auto-style12" style="width: 670px">Last Updated: N/A</td>
			<td class="auto-style15" style="width: 670px">
			<span class="auto-style14">Last </span><span class="auto-style13">
			Updated</span><span class="auto-style14">: Oct 4, 2016</span></td>
			<td class="auto-style12">Last Updated: Oct 4, 2016</td>
		</tr>
		<tr>
			<td class="auto-style2" colspan="4">
			<table style="width: 100%">
				<tr>
					<td class="auto-style2" style="height: 50px">
					<asp:Button id="Button5" runat="server" BackColor="#999966" Font-Bold="True" Height="25px" Text="Rules" Width="100px" />
					</td>
					<td class="auto-style2" style="height: 50px">
					<asp:Button id="Button6" runat="server" BackColor="#999966" Font-Bold="True" Height="25px" Text="Contacts" Width="100px" />
					</td>
					<td class="auto-style2" style="height: 50px">
					<asp:Button id="Button7" runat="server" BackColor="#999966" Font-Bold="True" Height="25px" Text="FAQs" Width="100px" />
					</td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td class="auto-style10" colspan="3" style="width: 70%" valign="top">
			<p class="auto-style5"><font face="georgia, times new roman, times">
			<strong>2016-17 Startup</strong></font></p>
			<p class="auto-style4"><font face="georgia, times new roman, times">
			First games will be on September 28, 2016.&nbsp; Full schedules are 
			accessible via the menu on the left, or from the Division pages 
			linked above.&nbsp; </font></p>
			<p class="auto-style4"><font face="georgia, times new roman, times">
			Some divisions have done this in the past, and all are requested to 
			do so this year:&nbsp; <span class="auto-style6"><strong>all</strong></span> 
			teams should report their results to the division co-ordinator, on 
			Wednesday night or Thursday.&nbsp; This will allow us to be able to 
			post standings more consistently and with less effort for the 
			co-ordinators.</font></p>
			<p class="auto-style4"><font face="georgia, times new roman, times">
			Good luck to all teams! Have a great season!</font></p>
			<p class="auto-style4">&nbsp;</p>
			<p class="auto-style7"><font face="georgia, times new roman, times">
			<strong>2015-16 Playoff Results</strong><msthemelist border="0" cellpadding="0" cellspacing="0" width="100%">
		<msthemelist></font></p>
			<p class="auto-style2"><font face="georgia,times new roman,times">
			<span class="auto-style9">Congratulations to V-Ballin' for winning 
			the C Division<br />
			</span></font><span class="auto-style9">Congratulations to Notorious 
			DIG for winning the D1 Division</span><br class="auto-style9" />
			<font face="georgia, times new roman, times">
			<span class="auto-style9">Congratulations to Set for Life for 
			winning the D2 Division<br />
			Congratulations to That Team for winning the E Division</span></font></p>
			<p class="auto-style4">&nbsp;</p>
			</td>
			<td style="width: 30%">
			<table border="1" bordercolordark="#996600" bordercolorlight="#996600" cellpadding="2" height="446" width="90%">
				<tr>
					<td align="center" bgcolor="#999966" bordercolordark="#FFFFFF" bordercolorlight="#FFFFFF" height="171" style="border-left: 0px none; margin-left: auto;" valign="top" width="20%">
					<p><font color="#ffffff"><b>Announcements</b></font></p>
					<p class="auto-style1">League Executive Changes</p>
					<p class="auto-style2">As we enter the 2016-17 season, there 
					are some changes to the League Executive.</p>
					<p class="auto-style2">Dave O'Neil takes over as Commission 
					/ Convenor / All-knowing Leader.&nbsp; Dave has been the E 
					division co-ordinator for many years, and brings a wealth of 
					knowledge, energy and experience to this position. Dave 
					plays for Scared Hitless</p>
					<p class="auto-style2">Tom Shaw is our new Treasurer.&nbsp; 
					Tom has also been involved in our league and on the 
					executive for many years, and plays for Sets Addicts.</p>
					<p class="auto-style2">Doug Clements has stepped down as 
					league Convenor, and will help out as Past Convenor and as 
					Web Master.</p>
					<p class="auto-style2">Our co-ordinators will remain the 
					same as in recent years - Cory Sabourin in C, Wayne 
					Podhornik and Wayne Zhang in D1, Tom Shaw in D2, and Dave 
					O'Neil in E.&nbsp; We welcome any inquiries from players to 
					become involved as executive members.</p>
					</td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td style="width: 185px">&nbsp;</td>
			<td colspan="2" style="width: 670px">&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 185px">&nbsp;</td>
			<td colspan="2" style="width: 670px">&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
	</table>
	</p>
</form>

</body>

</html>
